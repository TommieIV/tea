# TEA Roadmap

This is a running roadmap. Do not attempt to complete the entire roadmap at once.

# v0.1 — Installable Platform Shell

## Primary Goal
> Install TEA on a phone, log in, enter an active workspace, land on a generic Dashboard, and open a placeholder module.

## Foundation
- [ ] Choose frontend/PWA framework
- [ ] Choose backend/API approach
- [ ] Choose database
- [ ] Choose authentication approach
- [ ] Establish development / production environment strategy
- [ ] Initialize repository/project
- [ ] Establish Core vs Modules folder structure
- [ ] Configure environment-variable handling
- [ ] Configure linting/formatting/type checking as appropriate

## PWA
- [ ] Add web app manifest
- [ ] Add application icons/placeholders
- [ ] Configure installable behavior
- [ ] Establish service worker strategy
- [ ] Cache basic app shell
- [ ] Add online/offline indication
- [ ] Verify installed app launches on phone

## Authentication
- [ ] Create generic login screen
- [ ] Implement login
- [ ] Implement logout
- [ ] Persist session appropriately
- [ ] Protect authenticated routes
- [ ] Define basic user model
- [ ] Avoid personalization in Core

## Workspace Foundation
- [ ] Define workspace concept
- [ ] Define Personal, Household, and Business workspace types
- [ ] Define membership concept
- [ ] Allow authenticated session to resolve an active workspace
- [ ] Add basic workspace display/selector foundation
- [ ] Keep workspace data separated conceptually

## Permissions Foundation
- [ ] Adopt namespaced permission convention
- [ ] Document `{module}.{resource/function}.{action}`
- [ ] Define role-as-permission-bundle concept
- [ ] Leave room for permission checks in Core
- [ ] Do not overbuild advanced permission management in v0.1
- [ ] Ensure future backend authorization can enforce permissions

## Dashboard
- [ ] Create Dashboard route
- [ ] Add generic TEA branding/header
- [ ] Display logged-in user
- [ ] Display active workspace
- [ ] Build responsive module-card grid/list
- [ ] Render cards from module registry
- [ ] Add Connected state
- [ ] Add Coming Soon state
- [ ] Add Needs Setup state if useful
- [ ] Add Offline/Error state if useful
- [ ] Make connected cards navigable
- [ ] Make unavailable cards behave clearly

## Module Registry
- [ ] Create central registry
- [ ] Define module ID, display name, route, icon, status, enabled state
- [ ] Define supported workspace type foundation
- [ ] Define permission metadata foundation
- [ ] Leave room for module version
- [ ] Leave room for dashboard summary/widget metadata
- [ ] Leave room for module classification: generic/private/business/experimental

## Navigation
- [ ] Establish main navigation pattern
- [ ] Dashboard/Home navigation
- [ ] Back behavior
- [ ] Mobile-safe navigation
- [ ] Tablet/desktop adaptation
- [ ] Respect safe areas on installed mobile PWA

## Placeholder Module
- [ ] Create one example module folder
- [ ] Add module README
- [ ] Register it
- [ ] Define at least one example permission
- [ ] Enable it for one example workspace type
- [ ] Route Dashboard → module
- [ ] Route module → Dashboard
- [ ] Lazy-load/code-split it where practical
- [ ] Confirm unrelated modules are not required at startup

## Responsive Baseline
- [ ] Test phone, narrow phone, foldable/tablet, and desktop viewports
- [ ] Verify touch targets
- [ ] Verify navigation remains reachable
- [ ] Verify installed PWA layout

## v0.1 Exit Criteria
- [ ] TEA installs on phone
- [ ] User can log in
- [ ] Active workspace exists
- [ ] Dashboard renders from module registry
- [ ] At least one placeholder module is Connected
- [ ] At least one module is Coming Soon
- [ ] Connected module opens and returns to Dashboard
- [ ] Permission naming convention is established
- [ ] Core contains no hard-coded personal/business-specific logic
- [ ] App works at phone and desktop sizes
- [ ] Code is committed to Git

# v0.2 — Real Identity / Workspace / Permission Layer
- [ ] Real user persistence
- [ ] Workspace creation
- [ ] Workspace invitations
- [ ] Membership management
- [ ] Role definitions
- [ ] Permission assignment and enforcement
- [ ] Workspace-specific module enablement
- [ ] Module visibility by permission
- [ ] Workspace switcher UX

# v0.3 — First Real Module
- [ ] Select module
- [ ] Define purpose and supported workspace types
- [ ] Define permissions and data ownership
- [ ] Define routes/screens and offline requirements
- [ ] Define Dashboard integration
- [ ] Add module README
- [ ] Build in focused tasks
- [ ] Test independently and with Core
- [ ] Commit logical milestones

# Future Platform Capabilities
- Notifications / push notifications
- Shared task/reminder service
- File/photo storage
- Search
- Global activity feed
- Cross-module dashboard widgets
- Background sync
- User preferences
- Advanced roles / permission overrides
- Import/export
- Backup strategy
- Audit/history
- Family/shared-user features
- Automations
- External integrations
- Module marketplace/catalog concepts
- Public distribution strategy

# Parking Lot
- Family touchscreen dashboard
- Dad Mode
- Calendar
- Tasks
- Money
- Projects
- Vehicles
- Household
- Website management
- Business / side-work tools
- Personal utilities
- Additional modules as needs arise

# Development Rule
For every new idea, ask:
1. Is this Core functionality or a Module?
2. Which workspace types should support it?
3. What permissions should control it?
4. Does another module actually need it?
5. Can it be implemented without coupling unrelated features?
6. Does it belong in the current milestone or Parking Lot?
7. What is the smallest useful version?
