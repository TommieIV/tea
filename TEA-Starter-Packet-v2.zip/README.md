# TEA Starter Packet v2

This packet reflects the current architecture:

> **TEA is the platform / operating-system-like layer. Modules are the apps.**

Core stays generic. Users may belong to Personal, Household, and Business workspaces. Access is controlled with namespaced permissions such as `calendar.events.view`, `tasks.items.assign`, and `household.members.manage`.

Some modules may be private or business-specific without changing generic Core.

## Recommended Reading Order
1. `docs/TEA-VISION.md`
2. `docs/TEA-ARCHITECTURE.md`
3. `docs/ROADMAP.md`
4. `AGENTS.md`

## Immediate Goal

```text
Install PWA
→ Login
→ Workspace
→ Dashboard
→ Module Registry
→ Placeholder Module
```

Do not build real business modules until the platform shell is stable.
